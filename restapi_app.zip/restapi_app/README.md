# Event Management System API

A Spring Boot REST API for managing events, venues, and attendees.

## Features

- **Event Management**: Create, read, update, and delete events
- **Venue Management**: Manage event venues with capacity and location details
- **Attendee Management**: Track event registrations and attendee information
- **SQLite Database**: Lightweight database for easy deployment

## Technology Stack

- Java 21
- Spring Boot 3.5.5
- Spring Data JPA
- Hibernate
- SQLite Database
- Maven

## Database Schema

### Entities

1. **Event**
   - Event name, description, date
   - Event type (Conference, Workshop, Seminar, Webinar, Meetup, Concert, Other)
   - Capacity and status (Scheduled, Ongoing, Completed, Cancelled)
   - Linked to Venue

2. **Venue**
   - Name, location, capacity
   - Description

3. **Attendee**
   - Full name, email, phone
   - Registration date and status (Registered, Attended, Cancelled)
   - Linked to Event

## API Endpoints

### Events

- `GET /events` - Get all events
- `GET /events/{id}` - Get event by ID
- `POST /events` - Create new event
- `PUT /events/{id}` - Update event
- `DELETE /events/{id}` - Delete event

### Venues

- `GET /venues` - Get all venues
- `GET /venues/{id}` - Get venue by ID
- `POST /venues` - Create new venue
- `PUT /venues/{id}` - Update venue
- `DELETE /venues/{id}` - Delete venue

### Attendees

- `GET /attendees` - Get all attendees
- `GET /attendees/{id}` - Get attendee by ID
- `GET /attendees/event/{eventId}` - Get all attendees for an event
- `POST /attendees` - Register new attendee
- `PUT /attendees/{id}` - Update attendee
- `DELETE /attendees/{id}` - Delete attendee

## Getting Started

### Prerequisites

- Java 21 or higher
- Maven 3.6+

### Running the Application

1. Clone the repository
2. Navigate to project directory
3. Run the application:
   ```bash
   mvnw spring-boot:run
   ```
   Or on Windows:
   ```cmd
   mvnw.cmd spring-boot:run
   ```

4. The API will be available at `http://localhost:9080`

### Initialize Database

The database will be automatically created when you first run the application. To populate with sample data, you can run the SQL script:

```bash
sqlite3 eventdb.db < database_schema_sqlite.sql
```

## Example API Requests

### Create a Venue
```json
POST /venues
{
  "name": "Tech Conference Center",
  "location": "123 Tech Street, Silicon Valley",
  "capacity": 500,
  "description": "Modern conference center with state-of-the-art facilities"
}
```

### Create an Event
```json
POST /events
{
  "eventName": "Spring Boot Workshop 2025",
  "description": "Learn advanced Spring Boot techniques",
  "eventDate": "2025-06-15T10:00:00",
  "eventType": "Workshop",
  "venue": {
    "id": 1
  },
  "capacity": 50,
  "status": "Scheduled"
}
```

### Register an Attendee
```json
POST /attendees
{
  "event": {
    "id": 1
  },
  "fullName": "John Doe",
  "email": "john.doe@example.com",
  "phone": "555-1234",
  "registrationDate": "2025-01-20T14:30:00",
  "status": "Registered"
}
```

## Configuration

Application configuration can be found in `src/main/resources/application.properties`:

- Server port: 9080
- Database: SQLite (eventdb.db)
- JPA auto-DDL: update

## Project Structure

```
src/main/java/mssu/in/restapi_app/
├── controller/          # REST Controllers
├── entity/             # JPA Entities
├── repository/         # Data Access Layer
├── service/            # Business Logic Layer
└── exception/          # Custom Exceptions
```
