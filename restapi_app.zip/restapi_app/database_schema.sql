-- Event Management Database Schema
-- Create the database
CREATE DATABASE IF NOT EXISTS eventdb;
USE eventdb;

-- Create the venue table
CREATE TABLE IF NOT EXISTS venue (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(200) NOT NULL,
    location VARCHAR(300) NOT NULL,
    capacity INT NOT NULL,
    description TEXT
);

-- Create the event table
CREATE TABLE IF NOT EXISTS event (
    id INT PRIMARY KEY AUTO_INCREMENT,
    event_name VARCHAR(200) NOT NULL,
    description TEXT,
    event_date DATETIME NOT NULL,
    event_type VARCHAR(50) NOT NULL 
        CHECK (event_type IN ('Conference', 'Workshop', 'Seminar', 'Webinar', 'Meetup', 'Concert', 'Other')),
    venue_id INT,
    capacity INT NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'Scheduled'
        CHECK (status IN ('Scheduled', 'Ongoing', 'Completed', 'Cancelled')),
    FOREIGN KEY (venue_id) REFERENCES venue(id)
);

-- Create the attendee table
CREATE TABLE IF NOT EXISTS attendee (
    id INT PRIMARY KEY AUTO_INCREMENT,
    event_id INT NOT NULL,
    full_name VARCHAR(200) NOT NULL,
    email VARCHAR(200) NOT NULL,
    phone VARCHAR(20),
    registration_date DATETIME NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'Registered'
        CHECK (status IN ('Registered', 'Attended', 'Cancelled')),
    FOREIGN KEY (event_id) REFERENCES event(id) ON DELETE CASCADE
);

-- Sample data (optional)
INSERT INTO venue (name, location, capacity, description) 
VALUES 
    ('Grand Conference Hall', '123 Main Street, Downtown', 500, 'Large conference hall with modern facilities'),
    ('Tech Hub Auditorium', '456 Innovation Drive, Tech Park', 300, 'State-of-the-art auditorium for tech events'),
    ('Community Center', '789 Community Road', 150, 'Cozy venue for community gatherings');

INSERT INTO event (event_name, description, event_date, event_type, venue_id, capacity, status) 
VALUES 
    ('Spring Tech Conference 2025', 'Annual technology conference featuring latest innovations', '2025-03-15 09:00:00', 'Conference', 1, 500, 'Scheduled'),
    ('Java Workshop', 'Hands-on workshop on advanced Java programming', '2025-02-20 14:00:00', 'Workshop', 2, 50, 'Scheduled'),
    ('AI & ML Seminar', 'Exploring the future of artificial intelligence', '2025-04-10 10:00:00', 'Seminar', 2, 200, 'Scheduled');

INSERT INTO attendee (event_id, full_name, email, phone, registration_date, status) 
VALUES 
    (1, 'John Doe', 'john.doe@email.com', '555-0101', '2025-01-15 10:30:00', 'Registered'),
    (1, 'Jane Smith', 'jane.smith@email.com', '555-0102', '2025-01-16 14:20:00', 'Registered'),
    (2, 'Bob Johnson', 'bob.j@email.com', '555-0103', '2025-01-20 09:15:00', 'Registered');
