-- Event Management Database Schema for SQLite

-- Create the venue table
CREATE TABLE IF NOT EXISTS venue (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name VARCHAR(200) NOT NULL,
    location VARCHAR(300) NOT NULL,
    capacity INTEGER NOT NULL,
    description TEXT
);

-- Create the event table
CREATE TABLE IF NOT EXISTS event (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_name VARCHAR(200) NOT NULL,
    description TEXT,
    event_date TEXT NOT NULL,
    event_type VARCHAR(50) NOT NULL,
    venue_id INTEGER,
    capacity INTEGER NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'Scheduled',
    FOREIGN KEY (venue_id) REFERENCES venue(id)
);

-- Create the attendee table
CREATE TABLE IF NOT EXISTS attendee (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id INTEGER NOT NULL,
    full_name VARCHAR(200) NOT NULL,
    email VARCHAR(200) NOT NULL,
    phone VARCHAR(20),
    registration_date TEXT NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'Registered',
    FOREIGN KEY (event_id) REFERENCES event(id) ON DELETE CASCADE
);

-- Sample data
INSERT INTO venue (name, location, capacity, description) 
VALUES 
    ('Grand Conference Hall', '123 Main Street, Downtown', 500, 'Large conference hall with modern facilities'),
    ('Tech Hub Auditorium', '456 Innovation Drive, Tech Park', 300, 'State-of-the-art auditorium for tech events'),
    ('Community Center', '789 Community Road', 150, 'Cozy venue for community gatherings');

INSERT INTO event (event_name, description, event_date, event_type, venue_id, capacity, status) 
VALUES 
    ('Spring Tech Conference 2025', 'Annual technology conference featuring latest innovations', '2025-03-15 09:00:00', 'Conference', 1, 500, 'Scheduled'),
    ('Java Workshop', 'Hands-on workshop on advanced Java programming', '2025-02-20 14:00:00', 'Workshop', 2, 50, 'Scheduled'),
    ('AI & ML Seminar', 'Exploring the future of artificial intelligence', '2025-04-10 10:00:00', 'Seminar', 2, 200, 'Scheduled');

INSERT INTO attendee (event_id, full_name, email, phone, registration_date, status) 
VALUES 
    (1, 'John Doe', 'john.doe@email.com', '555-0101', '2025-01-15 10:30:00', 'Registered'),
    (1, 'Jane Smith', 'jane.smith@email.com', '555-0102', '2025-01-16 14:20:00', 'Registered'),
    (2, 'Bob Johnson', 'bob.j@email.com', '555-0103', '2025-01-20 09:15:00', 'Registered');
