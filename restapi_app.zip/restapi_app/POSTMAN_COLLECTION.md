# Postman CRUD Operations Guide

Base URL: `http://localhost:9080`

---

## 1. VENUE OPERATIONS

### CREATE Venue (POST)
**URL:** `http://localhost:9080/venues`  
**Method:** POST  
**Headers:** 
- Content-Type: application/json

**Body (raw JSON):**
```json
{
  "name": "Tech Conference Hall",
  "location": "123 Main Street, Downtown",
  "capacity": 500,
  "description": "Large conference hall with modern facilities"
}
```

**Expected Response (201 Created):**
```json
{
  "id": 1,
  "name": "Tech Conference Hall",
  "location": "123 Main Street, Downtown",
  "capacity": 500,
  "description": "Large conference hall with modern facilities"
}
```

---

### READ All Venues (GET)
**URL:** `http://localhost:9080/venues`  
**Method:** GET  
**Headers:** None required

**Expected Response (200 OK):**
```json
[
  {
    "id": 1,
    "name": "Tech Conference Hall",
    "location": "123 Main Street, Downtown",
    "capacity": 500,
    "description": "Large conference hall with modern facilities"
  }
]
```

---

### READ Single Venue (GET)
**URL:** `http://localhost:9080/venues/1`  
**Method:** GET  
**Headers:** None required

**Expected Response (200 OK):**
```json
{
  "id": 1,
  "name": "Tech Conference Hall",
  "location": "123 Main Street, Downtown",
  "capacity": 500,
  "description": "Large conference hall with modern facilities"
}
```

---

### UPDATE Venue (PUT)
**URL:** `http://localhost:9080/venues/1`  
**Method:** PUT  
**Headers:** 
- Content-Type: application/json

**Body (raw JSON):**
```json
{
  "name": "Updated Tech Conference Hall",
  "location": "456 Innovation Drive, Tech Park",
  "capacity": 600,
  "description": "Upgraded conference hall with latest technology"
}
```

**Expected Response (200 OK):**
```json
{
  "id": 1,
  "name": "Updated Tech Conference Hall",
  "location": "456 Innovation Drive, Tech Park",
  "capacity": 600,
  "description": "Upgraded conference hall with latest technology"
}
```

---

### DELETE Venue (DELETE)
**URL:** `http://localhost:9080/venues/1`  
**Method:** DELETE  
**Headers:** None required

**Expected Response (204 No Content):**
No body returned

---

## 2. EVENT OPERATIONS

### CREATE Event (POST)
**URL:** `http://localhost:9080/events`  
**Method:** POST  
**Headers:** 
- Content-Type: application/json

**Body (raw JSON):**
```json
{
  "eventName": "Spring Tech Conference 2025",
  "description": "Annual technology conference featuring latest innovations",
  "eventDate": "2025-03-15T09:00:00",
  "eventType": "Conference",
  "venue": {
    "id": 1
  },
  "capacity": 500,
  "status": "Scheduled"
}
```

**Event Types:** Conference, Workshop, Seminar, Webinar, Meetup, Concert, Other  
**Event Status:** Scheduled, Ongoing, Completed, Cancelled

**Expected Response (201 Created):**
```json
{
  "id": 1,
  "eventName": "Spring Tech Conference 2025",
  "description": "Annual technology conference featuring latest innovations",
  "eventDate": "2025-03-15T09:00:00",
  "eventType": "Conference",
  "venue": {
    "id": 1,
    "name": "Tech Conference Hall",
    "location": "123 Main Street, Downtown",
    "capacity": 500,
    "description": "Large conference hall with modern facilities"
  },
  "capacity": 500,
  "status": "Scheduled"
}
```

---

### READ All Events (GET)
**URL:** `http://localhost:9080/events`  
**Method:** GET  
**Headers:** None required

**Expected Response (200 OK):**
```json
[
  {
    "id": 1,
    "eventName": "Spring Tech Conference 2025",
    "description": "Annual technology conference featuring latest innovations",
    "eventDate": "2025-03-15T09:00:00",
    "eventType": "Conference",
    "venue": {
      "id": 1,
      "name": "Tech Conference Hall",
      "location": "123 Main Street, Downtown",
      "capacity": 500,
      "description": "Large conference hall with modern facilities"
    },
    "capacity": 500,
    "status": "Scheduled"
  }
]
```

---

### READ Single Event (GET)
**URL:** `http://localhost:9080/events/1`  
**Method:** GET  
**Headers:** None required

**Expected Response (200 OK):**
```json
{
  "id": 1,
  "eventName": "Spring Tech Conference 2025",
  "description": "Annual technology conference featuring latest innovations",
  "eventDate": "2025-03-15T09:00:00",
  "eventType": "Conference",
  "venue": {
    "id": 1,
    "name": "Tech Conference Hall",
    "location": "123 Main Street, Downtown",
    "capacity": 500,
    "description": "Large conference hall with modern facilities"
  },
  "capacity": 500,
  "status": "Scheduled"
}
```

---

### UPDATE Event (PUT)
**URL:** `http://localhost:9080/events/1`  
**Method:** PUT  
**Headers:** 
- Content-Type: application/json

**Body (raw JSON):**
```json
{
  "eventName": "Spring Tech Conference 2025 - Extended",
  "description": "Extended annual technology conference with more sessions",
  "eventDate": "2025-03-15T09:00:00",
  "eventType": "Conference",
  "venue": {
    "id": 1
  },
  "capacity": 600,
  "status": "Ongoing"
}
```

**Expected Response (200 OK):**
```json
{
  "id": 1,
  "eventName": "Spring Tech Conference 2025 - Extended",
  "description": "Extended annual technology conference with more sessions",
  "eventDate": "2025-03-15T09:00:00",
  "eventType": "Conference",
  "venue": {
    "id": 1,
    "name": "Tech Conference Hall",
    "location": "123 Main Street, Downtown",
    "capacity": 500,
    "description": "Large conference hall with modern facilities"
  },
  "capacity": 600,
  "status": "Ongoing"
}
```

---

### DELETE Event (DELETE)
**URL:** `http://localhost:9080/events/1`  
**Method:** DELETE  
**Headers:** None required

**Expected Response (204 No Content):**
No body returned

---

## 3. ATTENDEE OPERATIONS

### CREATE Attendee (POST)
**URL:** `http://localhost:9080/attendees`  
**Method:** POST  
**Headers:** 
- Content-Type: application/json

**Body (raw JSON):**
```json
{
  "event": {
    "id": 1
  },
  "fullName": "John Doe",
  "email": "john.doe@email.com",
  "phone": "555-0101",
  "registrationDate": "2025-01-20T10:30:00",
  "status": "Registered"
}
```

**Attendee Status:** Registered, Attended, Cancelled

**Expected Response (201 Created):**
```json
{
  "id": 1,
  "event": {
    "id": 1,
    "eventName": "Spring Tech Conference 2025",
    "description": "Annual technology conference featuring latest innovations",
    "eventDate": "2025-03-15T09:00:00",
    "eventType": "Conference",
    "venue": {
      "id": 1,
      "name": "Tech Conference Hall",
      "location": "123 Main Street, Downtown",
      "capacity": 500,
      "description": "Large conference hall with modern facilities"
    },
    "capacity": 500,
    "status": "Scheduled"
  },
  "fullName": "John Doe",
  "email": "john.doe@email.com",
  "phone": "555-0101",
  "registrationDate": "2025-01-20T10:30:00",
  "status": "Registered"
}
```

---

### READ All Attendees (GET)
**URL:** `http://localhost:9080/attendees`  
**Method:** GET  
**Headers:** None required

**Expected Response (200 OK):**
```json
[
  {
    "id": 1,
    "event": {
      "id": 1,
      "eventName": "Spring Tech Conference 2025",
      "description": "Annual technology conference featuring latest innovations",
      "eventDate": "2025-03-15T09:00:00",
      "eventType": "Conference",
      "venue": {
        "id": 1,
        "name": "Tech Conference Hall",
        "location": "123 Main Street, Downtown",
        "capacity": 500,
        "description": "Large conference hall with modern facilities"
      },
      "capacity": 500,
      "status": "Scheduled"
    },
    "fullName": "John Doe",
    "email": "john.doe@email.com",
    "phone": "555-0101",
    "registrationDate": "2025-01-20T10:30:00",
    "status": "Registered"
  }
]
```

---

### READ Single Attendee (GET)
**URL:** `http://localhost:9080/attendees/1`  
**Method:** GET  
**Headers:** None required

**Expected Response (200 OK):**
```json
{
  "id": 1,
  "event": {
    "id": 1,
    "eventName": "Spring Tech Conference 2025",
    "description": "Annual technology conference featuring latest innovations",
    "eventDate": "2025-03-15T09:00:00",
    "eventType": "Conference",
    "venue": {
      "id": 1,
      "name": "Tech Conference Hall",
      "location": "123 Main Street, Downtown",
      "capacity": 500,
      "description": "Large conference hall with modern facilities"
    },
    "capacity": 500,
    "status": "Scheduled"
  },
  "fullName": "John Doe",
  "email": "john.doe@email.com",
  "phone": "555-0101",
  "registrationDate": "2025-01-20T10:30:00",
  "status": "Registered"
}
```

---

### READ Attendees by Event (GET)
**URL:** `http://localhost:9080/attendees/event/1`  
**Method:** GET  
**Headers:** None required

**Expected Response (200 OK):**
```json
[
  {
    "id": 1,
    "event": {
      "id": 1,
      "eventName": "Spring Tech Conference 2025",
      "description": "Annual technology conference featuring latest innovations",
      "eventDate": "2025-03-15T09:00:00",
      "eventType": "Conference",
      "venue": {
        "id": 1,
        "name": "Tech Conference Hall",
        "location": "123 Main Street, Downtown",
        "capacity": 500,
        "description": "Large conference hall with modern facilities"
      },
      "capacity": 500,
      "status": "Scheduled"
    },
    "fullName": "John Doe",
    "email": "john.doe@email.com",
    "phone": "555-0101",
    "registrationDate": "2025-01-20T10:30:00",
    "status": "Registered"
  }
]
```

---

### UPDATE Attendee (PUT)
**URL:** `http://localhost:9080/attendees/1`  
**Method:** PUT  
**Headers:** 
- Content-Type: application/json

**Body (raw JSON):**
```json
{
  "event": {
    "id": 1
  },
  "fullName": "John Smith",
  "email": "john.smith@email.com",
  "phone": "555-9999",
  "registrationDate": "2025-01-20T10:30:00",
  "status": "Attended"
}
```

**Expected Response (200 OK):**
```json
{
  "id": 1,
  "event": {
    "id": 1,
    "eventName": "Spring Tech Conference 2025",
    "description": "Annual technology conference featuring latest innovations",
    "eventDate": "2025-03-15T09:00:00",
    "eventType": "Conference",
    "venue": {
      "id": 1,
      "name": "Tech Conference Hall",
      "location": "123 Main Street, Downtown",
      "capacity": 500,
      "description": "Large conference hall with modern facilities"
    },
    "capacity": 500,
    "status": "Scheduled"
  },
  "fullName": "John Smith",
  "email": "john.smith@email.com",
  "phone": "555-9999",
  "registrationDate": "2025-01-20T10:30:00",
  "status": "Attended"
}
```

---

### DELETE Attendee (DELETE)
**URL:** `http://localhost:9080/attendees/1`  
**Method:** DELETE  
**Headers:** None required

**Expected Response (204 No Content):**
No body returned

---

## Testing Order in Postman

Follow this sequence for best results:

1. **Create a Venue** (POST /venues)
2. **Get All Venues** (GET /venues) - Note the venue ID
3. **Create an Event** (POST /events) - Use the venue ID from step 2
4. **Get All Events** (GET /events) - Note the event ID
5. **Register an Attendee** (POST /attendees) - Use the event ID from step 4
6. **Get Attendees by Event** (GET /attendees/event/{eventId})
7. **Update Attendee Status** (PUT /attendees/{id}) - Change status to "Attended"
8. **Update Event Status** (PUT /events/{id}) - Change status to "Completed"

---

## Additional Test Data

### More Venues
```json
{
  "name": "Community Center",
  "location": "789 Community Road",
  "capacity": 150,
  "description": "Cozy venue for community gatherings"
}
```

### More Events
```json
{
  "eventName": "Java Workshop 2025",
  "description": "Hands-on workshop on advanced Java programming",
  "eventDate": "2025-02-20T14:00:00",
  "eventType": "Workshop",
  "venue": {
    "id": 2
  },
  "capacity": 50,
  "status": "Scheduled"
}
```

### More Attendees
```json
{
  "event": {
    "id": 1
  },
  "fullName": "Jane Smith",
  "email": "jane.smith@email.com",
  "phone": "555-0102",
  "registrationDate": "2025-01-21T14:20:00",
  "status": "Registered"
}
```

---

## Enum Values Reference

### Event Types
- Conference
- Workshop
- Seminar
- Webinar
- Meetup
- Concert
- Other

### Event Status
- Scheduled
- Ongoing
- Completed
- Cancelled

### Attendee Status
- Registered
- Attended
- Cancelled
