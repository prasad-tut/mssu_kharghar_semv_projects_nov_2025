# GitHub Setup Guide - Event Management System

## Step 1: Initialize Git Repository (if not already done)

Open your terminal in the project directory and run:

```cmd
git init
```

## Step 2: Create .gitignore File

This prevents unnecessary files from being uploaded to GitHub.

Create a `.gitignore` file with the following content (already created for you):

```
# Compiled class files
*.class
target/

# Log files
*.log

# Database files
*.db
*.db-journal

# IDE specific files
.idea/
*.iml
.vscode/
.settings/
.project
.classpath

# OS specific files
.DS_Store
Thumbs.db

# Maven
.mvn/
mvnw
mvnw.cmd

# Spring Boot
spring-boot-devtools.properties
```

## Step 3: Add All Files to Git

```cmd
git add .
```

## Step 4: Commit Your Changes

```cmd
git commit -m "Initial commit: Event Management System with CRUD operations"
```

## Step 5: Create a New Repository on GitHub

1. Go to [GitHub](https://github.com)
2. Click the "+" icon in the top right corner
3. Select "New repository"
4. Enter repository details:
   - **Repository name:** `event-management-system` (or your preferred name)
   - **Description:** "Spring Boot REST API for Event Management with CRUD operations"
   - **Visibility:** Choose Public or Private
   - **DO NOT** initialize with README, .gitignore, or license (we already have these)
5. Click "Create repository"

## Step 6: Connect Local Repository to GitHub

After creating the repository, GitHub will show you commands. Use these:

```cmd
git remote add origin https://github.com/YOUR_USERNAME/event-management-system.git
git branch -M main
git push -u origin main
```

**Replace `YOUR_USERNAME` with your actual GitHub username!**

## Step 7: Verify Upload

1. Refresh your GitHub repository page
2. You should see all your files uploaded

---

## Quick Command Reference

### First Time Setup (Complete Flow)

```cmd
# 1. Initialize git
git init

# 2. Add all files
git add .

# 3. Commit
git commit -m "Initial commit: Event Management System"

# 4. Add remote repository (replace YOUR_USERNAME)
git remote add origin https://github.com/YOUR_USERNAME/event-management-system.git

# 5. Push to GitHub
git branch -M main
git push -u origin main
```

---

## Future Updates (After Initial Push)

When you make changes to your project:

```cmd
# 1. Check what files changed
git status

# 2. Add changed files
git add .

# 3. Commit with a message
git commit -m "Description of your changes"

# 4. Push to GitHub
git push
```

---

## Common Git Commands

### Check Status
```cmd
git status
```

### View Commit History
```cmd
git log
```

### Create a New Branch
```cmd
git checkout -b feature-branch-name
```

### Switch Between Branches
```cmd
git checkout main
git checkout feature-branch-name
```

### Pull Latest Changes from GitHub
```cmd
git pull
```

### Remove a File from Git (but keep locally)
```cmd
git rm --cached filename
```

---

## Troubleshooting

### Error: "remote origin already exists"
```cmd
git remote remove origin
git remote add origin https://github.com/YOUR_USERNAME/event-management-system.git
```

### Error: "failed to push some refs"
```cmd
git pull origin main --rebase
git push -u origin main
```

### Error: Authentication Failed
- Use GitHub Personal Access Token instead of password
- Go to GitHub Settings → Developer settings → Personal access tokens
- Generate new token with 'repo' permissions
- Use token as password when prompted

---

## Using SSH Instead of HTTPS (Optional)

### Setup SSH Key
```cmd
# Generate SSH key
ssh-keygen -t ed25519 -C "your_email@example.com"

# Copy public key
type %USERPROFILE%\.ssh\id_ed25519.pub
```

### Add SSH Key to GitHub
1. Go to GitHub Settings → SSH and GPG keys
2. Click "New SSH key"
3. Paste your public key
4. Save

### Use SSH URL
```cmd
git remote set-url origin git@github.com:YOUR_USERNAME/event-management-system.git
```

---

## Recommended Repository Description

**About Section:**
```
Spring Boot REST API for Event Management System featuring:
- Event, Venue, and Attendee management
- Full CRUD operations
- SQLite database
- JPA/Hibernate
- Postman collection included
```

**Topics/Tags:**
```
spring-boot, rest-api, java, event-management, crud, jpa, hibernate, sqlite, maven
```

---

## What Gets Uploaded

✅ Source code (src/)
✅ Configuration files (pom.xml, application.properties)
✅ Documentation (README.md, POSTMAN_COLLECTION.md)
✅ Database schema (SQL files)
✅ Postman collection

❌ Compiled files (target/)
❌ Database files (*.db)
❌ IDE files (.idea/, *.iml)
❌ Maven wrapper (mvnw, mvnw.cmd)

---

## After Pushing to GitHub

Your repository will be accessible at:
```
https://github.com/YOUR_USERNAME/event-management-system
```

Share this link with others to showcase your project!
