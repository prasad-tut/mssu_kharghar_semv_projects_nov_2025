package mssu.in.restapi_app.service;

import java.util.List;
import mssu.in.restapi_app.entity.Venue;

public interface VenueService {
    List<Venue> getAllVenues();
    Venue getVenueById(Integer id);
    Venue createVenue(Venue venue);
    Venue updateVenue(Integer id, Venue venue);
    void deleteVenue(Integer id);
}
