package mssu.in.restapi_app.entity;

public enum EventType {
    Conference,
    Workshop,
    Seminar,
    Webinar,
    Meetup,
    Concert,
    Other
}
