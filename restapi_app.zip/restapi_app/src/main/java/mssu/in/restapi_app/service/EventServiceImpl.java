package mssu.in.restapi_app.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import mssu.in.restapi_app.entity.Event;
import mssu.in.restapi_app.repository.EventJpaRepository;
import mssu.in.restapi_app.exception.ResourceNotFoundException;

@Service
public class EventServiceImpl implements EventService {
    
    @Autowired
    private EventJpaRepository eventRepository;
    
    @Override
    public List<Event> getAllEvents() {
        return eventRepository.findAll();
    }
    
    @Override
    public Event getEventById(Integer id) {
        return eventRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Event not found with id: " + id));
    }
    
    @Override
    public Event createEvent(Event event) {
        return eventRepository.save(event);
    }
    
    @Override
    public Event updateEvent(Integer id, Event event) {
        Event existingEvent = getEventById(id);
        existingEvent.setEventName(event.getEventName());
        existingEvent.setDescription(event.getDescription());
        existingEvent.setEventDate(event.getEventDate());
        existingEvent.setEventType(event.getEventType());
        existingEvent.setVenue(event.getVenue());
        existingEvent.setCapacity(event.getCapacity());
        existingEvent.setStatus(event.getStatus());
        return eventRepository.save(existingEvent);
    }
    
    @Override
    public void deleteEvent(Integer id) {
        Event event = getEventById(id);
        eventRepository.delete(event);
    }
}
