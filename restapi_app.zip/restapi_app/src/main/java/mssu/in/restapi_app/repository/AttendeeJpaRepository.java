package mssu.in.restapi_app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import mssu.in.restapi_app.entity.Attendee;
import java.util.List;

@Repository
public interface AttendeeJpaRepository extends JpaRepository<Attendee, Integer> {
    List<Attendee> findByEventId(Integer eventId);
}
