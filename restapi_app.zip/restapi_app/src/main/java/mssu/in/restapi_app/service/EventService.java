package mssu.in.restapi_app.service;

import java.util.List;
import mssu.in.restapi_app.entity.Event;

public interface EventService {
    List<Event> getAllEvents();
    Event getEventById(Integer id);
    Event createEvent(Event event);
    Event updateEvent(Integer id, Event event);
    void deleteEvent(Integer id);
}
