package mssu.in.restapi_app.entity;

public enum AttendeeStatus {
    Registered,
    Attended,
    Cancelled
}
