package mssu.in.restapi_app.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import mssu.in.restapi_app.entity.Attendee;
import mssu.in.restapi_app.repository.AttendeeJpaRepository;
import mssu.in.restapi_app.exception.ResourceNotFoundException;

@Service
public class AttendeeServiceImpl implements AttendeeService {
    
    @Autowired
    private AttendeeJpaRepository attendeeRepository;
    
    @Override
    public List<Attendee> getAllAttendees() {
        return attendeeRepository.findAll();
    }
    
    @Override
    public List<Attendee> getAttendeesByEventId(Integer eventId) {
        return attendeeRepository.findByEventId(eventId);
    }
    
    @Override
    public Attendee getAttendeeById(Integer id) {
        return attendeeRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Attendee not found with id: " + id));
    }
    
    @Override
    public Attendee createAttendee(Attendee attendee) {
        return attendeeRepository.save(attendee);
    }
    
    @Override
    public Attendee updateAttendee(Integer id, Attendee attendee) {
        Attendee existingAttendee = getAttendeeById(id);
        existingAttendee.setEvent(attendee.getEvent());
        existingAttendee.setFullName(attendee.getFullName());
        existingAttendee.setEmail(attendee.getEmail());
        existingAttendee.setPhone(attendee.getPhone());
        existingAttendee.setRegistrationDate(attendee.getRegistrationDate());
        existingAttendee.setStatus(attendee.getStatus());
        return attendeeRepository.save(existingAttendee);
    }
    
    @Override
    public void deleteAttendee(Integer id) {
        Attendee attendee = getAttendeeById(id);
        attendeeRepository.delete(attendee);
    }
}
