package mssu.in.restapi_app.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import mssu.in.restapi_app.entity.Attendee;
import mssu.in.restapi_app.service.AttendeeService;

@RestController
@RequestMapping("/attendees")
public class AttendeeController {
    
    @Autowired
    private AttendeeService attendeeService;
    
    @GetMapping
    public ResponseEntity<List<Attendee>> getAllAttendees() {
        List<Attendee> attendees = attendeeService.getAllAttendees();
        return new ResponseEntity<>(attendees, HttpStatus.OK);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Attendee> getAttendeeById(@PathVariable Integer id) {
        Attendee attendee = attendeeService.getAttendeeById(id);
        return new ResponseEntity<>(attendee, HttpStatus.OK);
    }
    
    @GetMapping("/event/{eventId}")
    public ResponseEntity<List<Attendee>> getAttendeesByEventId(@PathVariable Integer eventId) {
        List<Attendee> attendees = attendeeService.getAttendeesByEventId(eventId);
        return new ResponseEntity<>(attendees, HttpStatus.OK);
    }
    
    @PostMapping
    public ResponseEntity<Attendee> createAttendee(@RequestBody Attendee attendee) {
        Attendee newAttendee = attendeeService.createAttendee(attendee);
        return new ResponseEntity<>(newAttendee, HttpStatus.CREATED);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Attendee> updateAttendee(@PathVariable Integer id, @RequestBody Attendee attendee) {
        Attendee updatedAttendee = attendeeService.updateAttendee(id, attendee);
        return new ResponseEntity<>(updatedAttendee, HttpStatus.OK);
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteAttendee(@PathVariable Integer id) {
        attendeeService.deleteAttendee(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
