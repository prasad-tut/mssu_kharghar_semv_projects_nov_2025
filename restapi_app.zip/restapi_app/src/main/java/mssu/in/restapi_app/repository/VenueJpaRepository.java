package mssu.in.restapi_app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import mssu.in.restapi_app.entity.Venue;

@Repository
public interface VenueJpaRepository extends JpaRepository<Venue, Integer> {
}
