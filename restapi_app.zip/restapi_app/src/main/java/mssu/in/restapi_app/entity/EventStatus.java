package mssu.in.restapi_app.entity;

public enum EventStatus {
    Scheduled,
    Ongoing,
    Completed,
    Cancelled
}
