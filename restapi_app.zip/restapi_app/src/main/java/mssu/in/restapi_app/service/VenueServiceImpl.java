package mssu.in.restapi_app.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import mssu.in.restapi_app.entity.Venue;
import mssu.in.restapi_app.repository.VenueJpaRepository;
import mssu.in.restapi_app.exception.ResourceNotFoundException;

@Service
public class VenueServiceImpl implements VenueService {
    
    @Autowired
    private VenueJpaRepository venueRepository;
    
    @Override
    public List<Venue> getAllVenues() {
        return venueRepository.findAll();
    }
    
    @Override
    public Venue getVenueById(Integer id) {
        return venueRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Venue not found with id: " + id));
    }
    
    @Override
    public Venue createVenue(Venue venue) {
        return venueRepository.save(venue);
    }
    
    @Override
    public Venue updateVenue(Integer id, Venue venue) {
        Venue existingVenue = getVenueById(id);
        existingVenue.setName(venue.getName());
        existingVenue.setLocation(venue.getLocation());
        existingVenue.setCapacity(venue.getCapacity());
        existingVenue.setDescription(venue.getDescription());
        return venueRepository.save(existingVenue);
    }
    
    @Override
    public void deleteVenue(Integer id) {
        Venue venue = getVenueById(id);
        venueRepository.delete(venue);
    }
}
