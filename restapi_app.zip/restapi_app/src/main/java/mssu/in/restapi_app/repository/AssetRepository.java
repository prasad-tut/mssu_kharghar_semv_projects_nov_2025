package mssu.in.restapi_app.repository;

import java.util.List;
import mssu.in.restapi_app.entity.Asset;

public interface AssetRepository {
    List<Asset> getAllAssets();
    Asset addNewAsset(Asset asset);
    Asset editAsset(Asset asset);
    void deleteAsset(Integer id);
    Asset getAssetById(Integer id);
}
