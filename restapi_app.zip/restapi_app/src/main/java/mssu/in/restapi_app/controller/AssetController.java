package mssu.in.restapi_app.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import mssu.in.restapi_app.entity.Asset;
import mssu.in.restapi_app.service.AssetService;

@RestController
@RequestMapping("/assets")
public class AssetController {
    
    @Autowired
    private AssetService assetService;
    
    @GetMapping
    public ResponseEntity<List<Asset>> getAllAssets() {
        List<Asset> assets = assetService.getAllAssets();
        return new ResponseEntity<>(assets, HttpStatus.OK);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Asset> getAssetById(@PathVariable Integer id) {
        Asset asset = assetService.getAssetById(id);
        return new ResponseEntity<>(asset, HttpStatus.OK);
    }
    
    @PostMapping
    public ResponseEntity<Asset> addNewAsset(@RequestBody Asset asset) {
        Asset newAsset = assetService.addNewAsset(asset);
        return new ResponseEntity<>(newAsset, HttpStatus.CREATED);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Asset> updateAsset(@PathVariable Integer id, @RequestBody Asset asset) {
        Asset updatedAsset = assetService.updateAsset(id, asset);
        return new ResponseEntity<>(updatedAsset, HttpStatus.OK);
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteAsset(@PathVariable Integer id) {
        assetService.deleteAsset(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
