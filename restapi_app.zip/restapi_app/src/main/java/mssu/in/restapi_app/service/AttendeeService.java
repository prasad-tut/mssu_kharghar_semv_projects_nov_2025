package mssu.in.restapi_app.service;

import java.util.List;
import mssu.in.restapi_app.entity.Attendee;

public interface AttendeeService {
    List<Attendee> getAllAttendees();
    List<Attendee> getAttendeesByEventId(Integer eventId);
    Attendee getAttendeeById(Integer id);
    Attendee createAttendee(Attendee attendee);
    Attendee updateAttendee(Integer id, Attendee attendee);
    void deleteAttendee(Integer id);
}
