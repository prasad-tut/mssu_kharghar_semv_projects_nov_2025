package mssu.in.restapi_app.repository;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import mssu.in.restapi_app.entity.Asset;
import mssu.in.restapi_app.exception.ResourceNotFoundException;

@Repository
public class AssetRepositoryImpl implements AssetRepository {
    
    @Autowired
    private AssetJpaRepository assetJpaRepository;
    
    @Override
    public List<Asset> getAllAssets() {
        return assetJpaRepository.findAll();
    }
    
    @Override
    public Asset addNewAsset(Asset asset) {
        return assetJpaRepository.save(asset);
    }
    
    @Override
    public Asset editAsset(Asset asset) {
        if (!assetJpaRepository.existsById(asset.getId())) {
            throw new ResourceNotFoundException("Asset not found with id: " + asset.getId());
        }
        return assetJpaRepository.save(asset);
    }
    
    @Override
    public void deleteAsset(Integer id) {
        if (!assetJpaRepository.existsById(id)) {
            throw new ResourceNotFoundException("Asset not found with id: " + id);
        }
        assetJpaRepository.deleteById(id);
    }
    
    @Override
    public Asset getAssetById(Integer id) {
        return assetJpaRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Asset not found with id: " + id));
    }
}
