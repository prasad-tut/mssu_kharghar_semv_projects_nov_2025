-- Asset Management System Database Schema

-- Asset Type Enum Values:
-- 'Hardware', 'Software', 'Furniture', 'Vehicle', 'Equipment', 'Other'

CREATE TABLE IF NOT EXISTS asset (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    asset_name VARCHAR(255) NOT NULL,
    description TEXT,
    asset_type VARCHAR(50) NOT NULL,
    purchase_date DATE,
    purchase_price DECIMAL(10, 2)
);

-- Sample Data
INSERT INTO asset (asset_name, description, asset_type, purchase_date, purchase_price) VALUES
('Dell Laptop XPS 15', 'High-performance laptop for development', 'Hardware', '2025-01-15', 1500.00),
('Microsoft Office 365', 'Annual subscription for productivity suite', 'Software', '2025-01-01', 299.99),
('Herman Miller Chair', 'Ergonomic office chair', 'Furniture', '2024-12-10', 850.00),
('Toyota Camry 2024', 'Company vehicle for sales team', 'Vehicle', '2024-11-20', 28000.00),
('HP LaserJet Printer', 'Office printer with scanning capability', 'Equipment', '2025-01-05', 450.00);
