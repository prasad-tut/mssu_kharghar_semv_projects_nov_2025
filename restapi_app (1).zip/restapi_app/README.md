# Asset Management System API

A Spring Boot REST API for managing organizational assets.

## Features

- **Asset Management**: Create, read, update, and delete assets
- **Asset Type Classification**: Categorize assets (Hardware, Software, Furniture, Vehicle, Equipment, Other)
- **SQLite Database**: Lightweight database for easy deployment
- **RESTful API**: Standard HTTP methods for all operations

## Technology Stack

- Java 21
- Spring Boot 3.5.5
- Spring Data JPA
- Hibernate
- SQLite Database
- Maven

## Database Schema

### Entities

1. **Asset**
   - Asset name, description
   - Asset type (Hardware, Software, Furniture, Vehicle, Equipment, Other)
   - Purchase date and price
   - Status tracking

## API Endpoints

### Assets

- `GET /assets` - Get all assets
- `GET /assets/{id}` - Get asset by ID
- `POST /assets` - Create new asset
- `PUT /assets/{id}` - Update asset
- `DELETE /assets/{id}` - Delete asset

## Getting Started

### Prerequisites

- Java 21 or higher
- Maven 3.6+

### Running the Application

1. Clone the repository
2. Navigate to project directory
3. Run the application:
   ```bash
   mvnw spring-boot:run
   ```
   Or on Windows:
   ```cmd
   mvnw.cmd spring-boot:run
   ```

4. The API will be available at `http://localhost:9080`

## Example API Requests

### Create an Asset
```json
POST /assets
{
  "assetName": "Dell Laptop XPS 15",
  "description": "High-performance laptop for development",
  "assetType": "Hardware",
  "purchaseDate": "2025-01-15",
  "purchasePrice": 1500.00
}
```

### Update an Asset
```json
PUT /assets/1
{
  "assetName": "Dell Laptop XPS 15",
  "description": "High-performance laptop for development - Updated",
  "assetType": "Hardware",
  "purchaseDate": "2025-01-15",
  "purchasePrice": 1500.00
}
```

## Configuration

Application configuration can be found in `src/main/resources/application.properties`:

- Server port: 9080
- Database: SQLite (assetdb.db)
- JPA auto-DDL: update

## Project Structure

```
src/main/java/mssu/in/restapi_app/
├── controller/          # REST Controllers
├── entity/             # JPA Entities
├── repository/         # Data Access Layer
├── service/            # Business Logic Layer
└── exception/          # Custom Exceptions
```
