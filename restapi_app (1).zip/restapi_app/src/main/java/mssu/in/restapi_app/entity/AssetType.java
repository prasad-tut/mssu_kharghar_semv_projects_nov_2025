package mssu.in.restapi_app.entity;

public enum AssetType {
    Hardware,
    Software,
    Infra
}
