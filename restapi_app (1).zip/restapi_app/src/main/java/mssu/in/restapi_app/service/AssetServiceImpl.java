package mssu.in.restapi_app.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import mssu.in.restapi_app.entity.Asset;
import mssu.in.restapi_app.repository.AssetRepository;

@Service
public class AssetServiceImpl implements AssetService {
    
    @Autowired
    private AssetRepository assetRepository;
    
    @Override
    public List<Asset> getAllAssets() {
        return assetRepository.getAllAssets();
    }
    
    @Override
    public Asset addNewAsset(Asset asset) {
        return assetRepository.addNewAsset(asset);
    }
    
    @Override
    public Asset updateAsset(Integer id, Asset asset) {
        asset.setId(id);
        return assetRepository.editAsset(asset);
    }
    
    @Override
    public void deleteAsset(Integer id) {
        assetRepository.deleteAsset(id);
    }
    
    @Override
    public Asset getAssetById(Integer id) {
        return assetRepository.getAssetById(id);
    }
}
