package mssu.in.restapi_app.entity;

import java.time.LocalDate;
import jakarta.persistence.*;

@Entity
@Table(name = "asset")
public class Asset {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
    
    @Column(name = "asset_number", nullable = false, length = 100)
    private String assetNumber;
    
    @Column(nullable = false, length = 100)
    private String description;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "asset_type", nullable = false, length = 10)
    private AssetType assetType;
    
    @Column(name = "purchased_on", nullable = false)
    private LocalDate purchasedOn;
    
    // Constructors
    public Asset() {}
    
    public Asset(String assetNumber, String description, AssetType assetType, LocalDate purchasedOn) {
        this.assetNumber = assetNumber;
        this.description = description;
        this.assetType = assetType;
        this.purchasedOn = purchasedOn;
    }
    
    // Getters and Setters
    public Integer getId() {
        return id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    
    public String getAssetNumber() {
        return assetNumber;
    }
    
    public void setAssetNumber(String assetNumber) {
        this.assetNumber = assetNumber;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public AssetType getAssetType() {
        return assetType;
    }
    
    public void setAssetType(AssetType assetType) {
        this.assetType = assetType;
    }
    
    public LocalDate getPurchasedOn() {
        return purchasedOn;
    }
    
    public void setPurchasedOn(LocalDate purchasedOn) {
        this.purchasedOn = purchasedOn;
    }
}
