package mssu.in.restapi_app.service;

import java.util.List;
import mssu.in.restapi_app.entity.Asset;

public interface AssetService {
    List<Asset> getAllAssets();
    Asset addNewAsset(Asset asset);
    Asset updateAsset(Integer id, Asset asset);
    void deleteAsset(Integer id);
    Asset getAssetById(Integer id);
}
